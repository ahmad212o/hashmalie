import React from 'react';

export default function projects() {
  return (
   <div>
       <h1> i am the projects</h1>
   </div>
  );
}
